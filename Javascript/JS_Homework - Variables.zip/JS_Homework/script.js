let firstName = "Darl Jed";
let lastName = "Matundan";


const msg =   'Hello, ' + firstName + " " + lastName +'! How can we help you today?';

console.log(msg);