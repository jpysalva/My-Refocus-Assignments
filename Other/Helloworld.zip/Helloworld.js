console.log("Hello, World!");
console.log("Im gonna be an awesome web developer!");
console.log("I want to be an indemand developer in the future!");